#include <stdlib.h>
#include <stdio.h>
#include <linux/unistd.h>

#include "bcm2835.h"

// Blinks on RPi pin GPIO 11
#define PIN RPI_V2_GPIO_P1_18

int main(int argc, char **argv)
{
    pid_t pID;
    uint8_t pinValue;

    pID = fork();

    if (pID == 0)  
    { 
        char genPidFile[80];

        sprintf( genPidFile, 
                 "echo %d > /var/run/ppPower.pid", getpid( ) );
        system( genPidFile );

        /* child process */
        if ( geteuid() != 0 )
        {
            printf( "this must be run as root user, exiting...\n");
            exit( 1 );
        }

        if (!bcm2835_init())
            return 1;

        bcm2835_gpio_set_pud( PIN, BCM2835_GPIO_PUD_UP );

        // Set the pin to be an input
        bcm2835_gpio_fsel( PIN, BCM2835_GPIO_FSEL_INPT );

        /*
        printf( "ppPower is listening for button press...\n");
        */

        // read gpio
        while (1)
        {
            // read pin
            pinValue = bcm2835_gpio_lev( PIN );
        
            // wait a bit
            delay(500);

            if ( pinValue == 0 )
            { 
                printf( "ppPower is shutting down!\n");

                sync( );
                system( "/sbin/halt" );
                sleep( 100 );

            }
            
        }
    }

    return 0;
}

